OCTS Employee Monthly Intelligence
==================================

Production-ready static website package.

Included:
- index.html
- Employee Monthly Report dashboard
- Search and leader filtering
- Performance bands
- Top performers
- Data-quality indicators
- AI Workforce Copilot UI

Source:
Employee Report Sheet.xlsx -> "Employee Monthly report" only.

Deployment:
1. Upload this folder to a static hosting provider such as Netlify or Vercel.
2. Set a custom domain/subdomain if required.
3. Do NOT make employee data publicly accessible without authentication.

Important:
The current site is a static prototype. For production use with employee data, add:
- Authentication
- Role-based access
- Secure database
- Audit logs
- HTTPS
- Backups
- Server-side authorization

The existing workbook values are preserved; suspicious/inconsistent source values are not silently altered.
